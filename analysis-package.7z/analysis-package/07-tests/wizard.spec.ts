import { describe, it, expect } from 'vitest';

describe('Wizard IA Onboarding (smoke)', () => {
  it('stub ok', () => {
    expect(true).toBe(true);
  });
});



